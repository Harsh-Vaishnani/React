import React from 'react'
import "./CommonCss/car.css"

function Props({img,title }) {
  return (
    <>
      <div class="card bg-dark text-white m-auto mb-5">
        <img src={img} class="card-img" alt="Stony Beach" />
        <div class="card-img-overlay">
          <h5 class="card-title">{title}</h5>
          <p class="card-text">
            This is a wider card with supporting text below as a natural lead-in to additional
            content. This content is a little bit longer.
          </p>
          
        </div>
      </div>
    </>
  )
}

export default Props