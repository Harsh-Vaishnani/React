import { useState } from 'react'
import Props from './Component/Props'
import Image1 from "./assets/Images/car-1.jpg"
import Image2 from "./assets/Images/car-2.jpg"
import Image3 from "./assets/Images/car-3.jpg"
import Image4 from "./assets/Images/car-4.jpg"



function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Props img={Image1} title="Lamborghini Aventador"/>
    <Props img={Image2} title="Bugatti Divo"/>
    <Props img={Image4} title="Lamborghini Huracan"/>
    <Props img={Image3} title="Bugatti Chiron"/>
    </>
  )
}

export default App
